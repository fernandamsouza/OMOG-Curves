# OMOG-Curves

Para executar:

```
	1. python3 omog.py;
	2. Selecione 4 pontos de controle no plano;
	3. A curva Bezier Grau 3 é gerada;
	4. Após, selecione mais 5 pontos de controle para geração da NURBS;
	5. A curva NURBS Grau 4 é gerada com continuidade C0 a Bezier Grau 3.
```
